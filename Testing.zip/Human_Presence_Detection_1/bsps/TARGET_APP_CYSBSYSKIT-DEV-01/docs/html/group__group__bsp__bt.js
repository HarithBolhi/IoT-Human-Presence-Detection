var group__group__bsp__bt =
[
    [ "CYBSP_BT_PLATFORM_CFG_BAUD_DOWNLOAD", "group__group__bsp__bt.html#gae6fcfdb93cc3e51a046b0cacbc49b4c2", null ],
    [ "CYBSP_BT_PLATFORM_CFG_BAUD_FEATURE", "group__group__bsp__bt.html#ga58d129cbeb845f8547f2140b8656ef88", null ],
    [ "CYBSP_BT_PLATFORM_CFG_BITS_DATA", "group__group__bsp__bt.html#ga874350ee5d9bfcafa5ddbb771f0770f9", null ],
    [ "CYBSP_BT_PLATFORM_CFG_BITS_STOP", "group__group__bsp__bt.html#gab7d4fad6bdee9bdff173acbbf1fbacee", null ],
    [ "CYBSP_BT_PLATFORM_CFG_MEM_POOL_BYTES", "group__group__bsp__bt.html#ga668864091ac3c80319d2051f04b1bddf", null ],
    [ "CYBSP_BT_PLATFORM_CFG_SLEEP_MODE_LP_ENABLED", "group__group__bsp__bt.html#ga9090c8f19b0abb9792e62f2649044a7e", null ],
    [ "cybsp_bt_platform_cfg", "group__group__bsp__bt.html#gad2a1cd8a260feac884c816510f34c23e", null ]
];